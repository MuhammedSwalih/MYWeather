//
//  MYWTableViewController.swift
//  MyWeather
//
//  Created by Mind Stand on 07/02/17.
//  Copyright © 2017 Mind Stand. All rights reserved.
//

import UIKit

class MYWTableViewController: UITableViewController, UISearchBarDelegate {

    @IBOutlet weak var serachBar: UISearchBar!
    
    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var placeLabel: UILabel!
    
    @IBOutlet weak var countryLabel: UILabel!
    
    @IBOutlet weak var temperatureLabel: UILabel!
    
    @IBOutlet weak var latitudeLabel: UILabel!
    
    @IBOutlet weak var longitudeLabel: UILabel!
    
    @IBOutlet var weatherCell: [UITableViewCell]!
    
    var placeName:String?
    
    var hiddenCellsID:[AnyObject] = []
    
    var numberOfRows = 7
    
    enum apiSettings:String{
        case BaseURL = "http://api.openweathermap.org/data/2.5/weather"
        case ApiKey = "YOUR API KEY HERE" //Login to 'www.openweathermap.org' & get API Key, Its FREE
        case imageBaseURL = "http://openweathermap.org/img/w/"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Weather"
        
        serachBar.showsScopeBar = true
        serachBar.delegate = self
        
        iconImageView.layer.cornerRadius = 10
        
        //Background image
        self.tableView.backgroundView = UIImageView(image: UIImage(named: "ic_background.jpg"))
        
        
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numberOfRows
    }
    
    func searchBarSearchButtonClicked( searchBar: UISearchBar)
    {
        
        if let placeName = serachBar.text! as? String {
            
            print(placeName)
            getWeatherData(placeName)
        }
        else{
            print("Input isn't a String")
        }
        
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if(indexPath.row > 1)
        {
            
            //Only Labels need to be hidden
            if(tableView.cellForRowAtIndexPath(indexPath)?.accessoryType == UITableViewCellAccessoryType.None){
                //Table view selection
                tableView.cellForRowAtIndexPath(indexPath)?.accessoryType = UITableViewCellAccessoryType.Checkmark
                
                //Add selected cell into array
                hiddenCellsID.append(indexPath)
            }
            else{
                //Table view Remove selection
                tableView.cellForRowAtIndexPath(indexPath)?.accessoryType = UITableViewCellAccessoryType.None
                
                //Remove Unselected cell from Array
                let tempArray = hiddenCellsID.filter() {$0 as! NSIndexPath != indexPath}
                
                hiddenCellsID = tempArray
            }
        }
    }
    
    
    
    //Get Country Names using APIs
    func getWeatherData(place:String){
        
        let urlString = apiSettings.BaseURL.rawValue + "?q=\(place)&appid=\(apiSettings.ApiKey.rawValue)"
        let url = NSURL(string: urlString)
        let requestURL: NSURLRequest = NSURLRequest(URL: url!)
        
        let countryTask = NSURLSession.sharedSession().dataTaskWithRequest(requestURL){(data, response, error) in
            
            //exception handling
            do{
                let responseDictionary = try! NSJSONSerialization.JSONObjectWithData(data!, options: []) as! NSDictionary
                
                
                dispatch_async(dispatch_get_main_queue(),{
                    
                    var cod :String?
                    if let status = responseDictionary["cod"] as? String{
                        
                        cod = status
                        
                    }
                    
                    if let status = responseDictionary["cod"] as? Int{
                        
                        cod = String(status)
                    }
                    
                    guard cod == "200" else{
                        //Error - Place not found
                        return
                    }
                    
                    //Set values
                    //Place
                    if let placeNameString = responseDictionary["name"] as? String{
                        
                        self.placeLabel.text = placeNameString
                        print(placeNameString)
                    }
                    
                    //Country
                    if let sysDictionary = responseDictionary["sys"] as? [String:AnyObject]{
                        
                        self.countryLabel.text = sysDictionary["country"] as? String
                    }
                    
                    //Temperature
                    if let mainDictionary = responseDictionary["main"] as? [String:AnyObject]{
                        
                        self.temperatureLabel.text = "\(mainDictionary["temp"]! as! Double - 273.15) °C"
                    }
                    
                    //Latitude & Longitude
                    if let coordDictionary = responseDictionary["coord"] as? [String:Double]{
                        
                        self.latitudeLabel.text = String(coordDictionary["lat"]!)
                        self.longitudeLabel.text = String(coordDictionary["lon"]!)
                        
                    }
                    
                    //icon
                    if let weatherDictionary = responseDictionary["weather"]![0] as? [String:AnyObject]{
                        let imageName = String(weatherDictionary["icon"]!)
                        
                        let imageURL = apiSettings.imageBaseURL.rawValue + imageName + ".png"
                        
                        print(imageURL)
                        
                        if let url = NSURL(string:imageURL) {
                            if let data = NSData(contentsOfURL: url) {
                                
                                self.iconImageView.backgroundColor = UIColor.whiteColor()
                                self.iconImageView.image = UIImage(data: data)
                                
                            }
                        }
                    }
                                        
                })
                
                
            }
            catch{
                print(error)
            }
            
        }
        
        countryTask.resume()
        
    }
    
    func DeleteCells(){
        tableView.beginUpdates()
        if(hiddenCellsID.count > 0){
            
            self.tableView.deleteRowsAtIndexPaths(hiddenCellsID as! [NSIndexPath], withRowAnimation: .None)
            numberOfRows = numberOfRows - hiddenCellsID.count
            hiddenCellsID = [] //Empty Array
            
        }
        tableView.endUpdates()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
